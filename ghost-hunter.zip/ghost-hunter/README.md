# Ghost Hunter

Bat counter and ghost bat ID — web v5.1.

Ghost Hunter counts bats flying in and out across a line you draw on a trail-cam video, and judges bat detector recordings (WAV) as ghost bat or other bat using an 80-tree learner trained on expert-identified calls from TERN EcoAcoustics.

## Use it

Open `index.html` in any modern browser (phone or laptop). Everything is in that one file.

To put it online with GitHub Pages: repository **Settings → Pages → Deploy from a branch → main / (root)**. The app will be at `https://<your-username>.github.io/<repo-name>/`.

## Privacy

- Everything runs on the device. Videos and recordings are never uploaded.
- A Content-Security-Policy blocks all network connections.
- No accounts, tracking, ads or cookies.

## Credits

Reference calls: TERN EcoAcoustics (CC BY 4.0) and their recordists. Built by Josh for ghost bat conservation.
